#!/bin/bash
# build-and-deploy.sh
# ============================================================
# RHEL 10 bootc s390x – Full build and DASD deploy script
# Build host : RHEL/Fedora with Podman (rootful recommended)
# Target     : IBM Z LPAR, RAW image → DASD
# ============================================================

set -euo pipefail

## ── Configuration ───────────────────────────────────────────
IMAGE_NAME="rhel10-bootc-s390x"
IMAGE_TAG="latest"
FULL_IMAGE="${IMAGE_NAME}:${IMAGE_TAG}"
OUTPUT_DIR="/var/tmp/bootc-output"
RAW_IMAGE="${OUTPUT_DIR}/rhel10-bootc-s390x.raw"

RH_REGISTRY="registry.redhat.io"
BUILDER_IMAGE="${RH_REGISTRY}/rhel10/bootc-image-builder:latest"

## Set to your KVM/LPAR transfer host if needed; leave blank to skip scp
DEPLOY_HOST=""         # e.g. "root@kvm-host.example.com"
DEPLOY_PATH="/var/lib/images/"

## ── Pre-flight checks ───────────────────────────────────────
preflight() {
    echo "==> Pre-flight checks"
    command -v podman >/dev/null 2>&1 || { echo "ERROR: podman not found"; exit 1; }
    command -v ssh    >/dev/null 2>&1 || echo "  WARN: ssh not found – remote deploy will be skipped"

    # Verify RHEL entitlement is present (needed for registry pulls inside build)
    if [ ! -f /etc/pki/entitlement/*.pem ] 2>/dev/null; then
        echo "  WARN: No entitlement certs found in /etc/pki/entitlement/"
        echo "        Run: subscription-manager register && subscription-manager attach"
    fi

    # Verify ssh/authorized_keys has a real key
    if grep -q "EXAMPLEKEYHERE" ssh/authorized_keys 2>/dev/null; then
        echo ""
        echo "  ERROR: ssh/authorized_keys still contains the placeholder key."
        echo "         Replace it with your actual public key before building."
        echo "         Generate one with: ssh-keygen -t ed25519 -C britley@workstation"
        exit 1
    fi

    mkdir -p "${OUTPUT_DIR}"
    echo "    OK: All pre-flight checks passed"
}

## ── Step 1: Login to Red Hat registry ──────────────────────
registry_login() {
    echo ""
    echo "==> [1/5] Logging in to ${RH_REGISTRY}"
    echo "    Enter your Red Hat Customer Portal username and password."
    echo "    (Or use a registry service account token from console.redhat.com)"
    podman login "${RH_REGISTRY}"
}

## ── Step 2: Build the bootc container image ─────────────────
build_image() {
    echo ""
    echo "==> [2/5] Building bootc container image: ${FULL_IMAGE}"
    echo "    Platform: linux/s390x (cross-arch build via QEMU binfmt)"
    echo ""

    # Enable cross-arch builds if qemu-user-static is installed
    if command -v qemu-s390x-static >/dev/null 2>&1; then
        podman run --rm --privileged \
            multiarch/qemu-user-static --reset -p yes 2>/dev/null || true
    fi

    podman build \
        --platform linux/s390x \
        --tls-verify=false \
        --volume /etc/pki/entitlement:/etc/pki/entitlement:ro \
        --volume /etc/rhsm:/etc/rhsm:ro \
        --volume /etc/yum.repos.d/redhat.repo:/etc/yum.repos.d/redhat.repo:ro \
        --network=host \
        -t "${FULL_IMAGE}" \
        -f containerfile/Containerfile \
        .

    echo "    Build complete: ${FULL_IMAGE}"
    podman images "${IMAGE_NAME}"
}

## ── Step 3: Convert to RAW disk image ───────────────────────
build_raw_image() {
    echo ""
    echo "==> [3/5] Converting to RAW disk image via bootc-image-builder"
    echo "    Output: ${RAW_IMAGE}"
    echo ""

    podman run --rm -it \
        --privileged \
        --security-opt seccomp=unconfined \
        -v /var/lib/containers:/var/lib/containers \
        -v "${OUTPUT_DIR}:/output" \
        "${BUILDER_IMAGE}" \
        --type raw \
        --target-arch s390x \
        "${FULL_IMAGE}"

    echo ""
    echo "    RAW image created:"
    ls -lh "${OUTPUT_DIR}"/*.raw 2>/dev/null || ls -lh "${OUTPUT_DIR}"
}

## ── Step 4: Validate the image ──────────────────────────────
validate_image() {
    echo ""
    echo "==> [4/5] Validating RAW image"
    RAW_FILE=$(find "${OUTPUT_DIR}" -name "*.raw" | head -1)
    if [ -z "${RAW_FILE}" ]; then
        echo "  ERROR: No .raw file found in ${OUTPUT_DIR}"
        exit 1
    fi
    SIZE=$(du -sh "${RAW_FILE}" | cut -f1)
    echo "    File   : ${RAW_FILE}"
    echo "    Size   : ${SIZE}"
    # Basic sanity: check for x86 partition table vs s390x (no MBR)
    file "${RAW_FILE}"
    echo "    OK: image validated"
}

## ── Step 5: Deploy to LPAR / KVM host ───────────────────────
deploy_image() {
    echo ""
    echo "==> [5/5] Deploy"
    RAW_FILE=$(find "${OUTPUT_DIR}" -name "*.raw" | head -1)

    if [ -z "${DEPLOY_HOST}" ]; then
        echo "    DEPLOY_HOST not set – skipping remote transfer."
        echo "    To transfer manually:"
        echo ""
        echo "      scp ${RAW_FILE} root@<kvm-host>:${DEPLOY_PATH}"
        echo ""
        echo "    Then on the IBM Z host, write to DASD:"
        echo ""
        echo "      # 1. Bring DASD online"
        echo "      cio_ignore -r 0.0.0200"
        echo "      chccwdev -e 0.0.0200"
        echo ""
        echo "      # 2. Low-level format (first time only – DESTRUCTIVE)"
        echo "      dasdfmt -b 4096 -d cdl -y /dev/dasda"
        echo ""
        echo "      # 3. Write image"
        echo "      dd if=${RAW_FILE##*/} of=/dev/dasda bs=64M status=progress"
        echo "      sync"
        echo ""
        echo "      # 4. Install zipl (if not already in image)"
        echo "      mount /dev/dasda1 /mnt"
        echo "      zipl --verbose --target /mnt"
        echo "      umount /mnt"
        echo ""
        echo "      # 5. IPL the DASD from HMC or z/VM"
        return
    fi

    echo "    Transferring ${RAW_FILE} → ${DEPLOY_HOST}:${DEPLOY_PATH}"
    scp "${RAW_FILE}" "${DEPLOY_HOST}:${DEPLOY_PATH}"
    echo "    Transfer complete."
}

## ── Main ────────────────────────────────────────────────────
main() {
    echo ""
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  RHEL 10 bootc s390x – Build & Deploy               ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo ""

    preflight
    registry_login
    build_image
    build_raw_image
    validate_image
    deploy_image

    echo ""
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  Build complete.                                     ║"
    echo "║                                                      ║"
    echo "║  First boot checklist:                               ║"
    echo "║  1. IPL the DASD from HMC                           ║"
    echo "║  2. Login: britley / Ch@ngeMe1st!                   ║"
    echo "║  3. Change password immediately when prompted        ║"
    echo "║  4. Add your SSH key, then disable password auth:   ║"
    echo "║       sudo sed -i 's/PasswordAuthentication yes/    ║"
    echo "║       PasswordAuthentication no/' /etc/ssh/sshd_config║"
    echo "║       sudo systemctl reload sshd                    ║"
    echo "║  5. Check first-boot LVM log:                       ║"
    echo "║       cat /var/log/firstboot-lvm.log                ║"
    echo "╚══════════════════════════════════════════════════════╝"
}

main "$@"

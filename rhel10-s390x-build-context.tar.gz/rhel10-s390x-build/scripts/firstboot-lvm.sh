#!/bin/bash
# /usr/local/sbin/firstboot-lvm.sh
# ------------------------------------------------------------
# Runs ONCE on first boot to:
#   1. Bring DASD 0.0.0200 online
#   2. Low-level format it (CDL, 4096-byte blocks)
#   3. Create a partition
#   4. Build LVM PV → VG (rhelvg) → LVs (root 40G, var 20G)
#   5. Format LVs as XFS
#   6. Self-disable this service so it never runs again
#
# WARNING: This script is DESTRUCTIVE. It will erase any
# existing data on the DASD device 0.0.0200.
# Adjust sizes below to match your disk capacity.
# ------------------------------------------------------------

set -euo pipefail
LOG=/var/log/firstboot-lvm.log
exec >> "$LOG" 2>&1

echo "=== firstboot-lvm started: $(date) ==="

DASD_ADDR="0.0.0200"
DASD_DEV="/dev/dasda"
VG_NAME="rhelvg"
ROOT_LV_SIZE="40G"
VAR_LV_SIZE="20G"

## Step 1: Remove from cio_ignore list and bring online
echo "[1/6] Bringing DASD ${DASD_ADDR} online..."
cio_ignore -r "${DASD_ADDR}" || true
chccwdev -e "${DASD_ADDR}"

## Wait for the device node to appear
for i in $(seq 1 20); do
    [ -b "${DASD_DEV}" ] && break
    echo "  waiting for ${DASD_DEV} ... (${i}/20)"
    sleep 1
done

if [ ! -b "${DASD_DEV}" ]; then
    echo "ERROR: ${DASD_DEV} did not appear after 20 seconds."
    exit 1
fi

## Step 2: Low-level format (CDL layout, 4096-byte blocks)
echo "[2/6] Low-level formatting ${DASD_DEV} (CDL, 4096b blocks)..."
dasdfmt -b 4096 -d cdl -y "${DASD_DEV}"

## Step 3: Create a single Linux partition
echo "[3/6] Partitioning ${DASD_DEV}..."
fdasd -a "${DASD_DEV}"
PART="${DASD_DEV}1"

## Wait for partition node
for i in $(seq 1 10); do
    [ -b "${PART}" ] && break
    sleep 1
done

## Step 4: LVM setup
echo "[4/6] Creating LVM PV, VG, and LVs..."
pvcreate "${PART}"
vgcreate "${VG_NAME}" "${PART}"
lvcreate -L "${ROOT_LV_SIZE}" -n root  "${VG_NAME}"
lvcreate -L "${VAR_LV_SIZE}"  -n var   "${VG_NAME}"

## Step 5: Format filesystems
echo "[5/6] Formatting LVs as XFS..."
mkfs.xfs -f "/dev/${VG_NAME}/root"
mkfs.xfs -f "/dev/${VG_NAME}/var"

## Step 6: Self-disable
echo "[6/6] Disabling firstboot-lvm service..."
systemctl disable firstboot-lvm.service

echo "=== firstboot-lvm complete: $(date) ==="
echo "    Root LV : /dev/${VG_NAME}/root (${ROOT_LV_SIZE})"
echo "    Var  LV : /dev/${VG_NAME}/var  (${VAR_LV_SIZE})"
echo "    Log     : ${LOG}"
